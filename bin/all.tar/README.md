A sample project of queydsl with Spring boot, Spring data JPA, JPA, MySQL, Hibernate, HikariCP
