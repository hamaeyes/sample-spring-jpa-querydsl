package com.arifng.jpaquerydsl.config;

public class RepositoryConfig {
}
